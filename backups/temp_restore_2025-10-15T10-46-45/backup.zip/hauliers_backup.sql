-- Backup for hauliers
-- 1 records
-- Generated: 2025-10-15T10:12:48.559Z

INSERT INTO hauliers ("id", "created_by", "created_at", "haulier_name", "contacts", "address", "telephone", "mobile") VALUES (E'8892e03a-08ad-47f9-a54e-a016c3484cc6', NULL, E'2025-10-10 11:18:02.544918+00', E'Emy Logistics', '[]'::jsonb, E'Unit 501 Leroy House, \n434-436 Essex Road, \nLondon, N1 3QP', E'', E'07584162821');

