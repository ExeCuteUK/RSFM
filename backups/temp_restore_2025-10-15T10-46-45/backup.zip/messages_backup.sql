-- Backup for messages
-- 2 records
-- Generated: 2025-10-15T10:12:48.572Z

INSERT INTO messages ("id", "sender_id", "recipient_id", "subject", "content", "attachments", "is_read", "created_at") VALUES (E'19b38fb0-7d17-4b45-94b2-29cd9d336e9a', E'f6ec8b73-01e0-48d4-ab62-4af13cde75d9', E'd0aba207-0936-423c-8c9b-ccd5854634fb', E'Slag', E'Eric reckons youre a bit of a slag', '[]'::jsonb, TRUE, E'2025-10-14 12:57:17.735789+00');
INSERT INTO messages ("id", "sender_id", "recipient_id", "subject", "content", "attachments", "is_read", "created_at") VALUES (E'493f69bf-8428-48ab-92c0-3695ad644f9c', E'd0aba207-0936-423c-8c9b-ccd5854634fb', E'f6ec8b73-01e0-48d4-ab62-4af13cde75d9', E'Briefcase...', E'Mong', '[]'::jsonb, TRUE, E'2025-10-14 13:00:08.319943+00');

