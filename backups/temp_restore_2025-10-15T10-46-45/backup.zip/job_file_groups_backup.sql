-- Backup for job_file_groups
-- 4 records
-- Generated: 2025-10-15T10:12:48.571Z

INSERT INTO job_file_groups ("id", "job_ref", "documents", "rs_invoices", "created_at", "updated_at") VALUES (E'a657f382-8664-4dbb-8187-d39f4b95f35e', 26001, '[]'::jsonb, '[]'::jsonb, E'2025-10-13T19:59:45.876Z', E'2025-10-14T14:16:57.852Z');
INSERT INTO job_file_groups ("id", "job_ref", "documents", "rs_invoices", "created_at", "updated_at") VALUES (E'3a2f7058-20e9-4831-9242-adfc529c397e', 26003, '[{"path":"/objects/1ftTqu48hpVM-wXBPTntOJStkOnuQZ9zC","filename":"TATBEY - MEERAN DRAFT BL.pdf"},{"path":"{\"filename\":\"ONEYISTF18511600_draft_20250917194022.pdf\",\"path\":\"/objects/1KfMn0PQwxGJlG4VHji5QbO0TEgFYvIA1\"}","filename":"1KfMn0PQwxGJlG4VHji5QbO0TEgFYvIA1\"}"}]'::jsonb, '[]'::jsonb, E'2025-10-14T14:16:12.901Z', E'2025-10-15T08:24:49.985Z');
INSERT INTO job_file_groups ("id", "job_ref", "documents", "rs_invoices", "created_at", "updated_at") VALUES (E'5422444d-7ef2-4fca-a56f-9db8932913af', 26002, '[{"path":"/objects/1yUNiO_c29MwgSqnCRndKKhRiMMZelGrB","filename":"4054820050 SSP DRAFT BL.pdf"},{"path":"/objects/1Pzkn6znp7LKGlL1GHjFkbYB6RiJrGsT3","filename":"4054820050-20250924060335.PDF"}]'::jsonb, '[]'::jsonb, E'2025-10-14T12:15:45.270Z', E'2025-10-15T08:25:08.321Z');
INSERT INTO job_file_groups ("id", "job_ref", "documents", "rs_invoices", "created_at", "updated_at") VALUES (E'368e7cff-42b2-4cd8-a139-8f1e213fdd28', 26004, '[{"path":"/objects/1OXoCv78Lds0OkBCcAcP6BvWX7Kg7wISt","filename":"[Untitled].pdf"},{"path":"/objects/14U1px-G2FSYUKqhmV9GoD1iZYOgY7DtQ","filename":"scan.pdf"}]'::jsonb, '[]'::jsonb, E'2025-10-15T10:02:25.018Z', E'2025-10-15T10:12:15.204Z');

