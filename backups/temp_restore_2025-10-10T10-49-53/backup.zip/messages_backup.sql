-- Backup for messages
-- 2 records
-- Generated: 2025-10-10T10:23:26.414Z

INSERT INTO messages ("id", "sender_id", "recipient_id", "subject", "content", "attachments", "is_read", "created_at") VALUES (E'6d9fc35b-68ed-474b-abe3-78b45568da6f', E'f6ec8b73-01e0-48d4-ab62-4af13cde0b6c', E'5ca65378-a12f-419d-8d75-09046447a6e2', E'TEST', E'TEST', ARRAY[], TRUE, E'2025-10-05 14:52:44.806+00');
INSERT INTO messages ("id", "sender_id", "recipient_id", "subject", "content", "attachments", "is_read", "created_at") VALUES (E'26c9628a-a06f-4d3b-96d2-e04bfb81453d', E'5ca65378-a12f-419d-8d75-09046447a6e2', E'f6ec8b73-01e0-48d4-ab62-4af13cde0b6c', E'efef', E'fewfw', ARRAY[], TRUE, E'2025-10-05 15:13:48.603175+00');

