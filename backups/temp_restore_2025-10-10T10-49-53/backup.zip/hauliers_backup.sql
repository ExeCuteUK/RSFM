-- Backup for hauliers
-- 1 records
-- Generated: 2025-10-10T10:23:25.995Z

INSERT INTO hauliers ("id", "created_by", "haulier_name", "contacts", "address", "telephone", "mobile") VALUES (E'8892e03a-08ad-47f9-a54e-a016c3484cc6', NULL, E'Emy Logistics', ARRAY[[object Object],[object Object]], E'Unit 501 Leroy House, \n434-436 Essex Road, \nLondon, N1 3QP', E'', E'07584162821');

