-- Backup for settings
-- 1 records
-- Generated: 2025-10-10T10:23:26.652Z

INSERT INTO settings ("id", "import_clearance_fee", "inventory_linked_fee", "commodity_codes_included_free", "additional_commodity_code_charge", "deferment_charge_minimum", "deferment_charge_percentage", "handover_fee") VALUES (E'86cf6783-7783-4050-b1bb-b0ee72ea95a7', E'55.00', E'20.00', 1, E'5.00', E'45.00', E'1.25', E'30.00');

