-- Backup for purchase_invoices
-- 3 records
-- Generated: 2025-10-10T10:23:26.474Z

INSERT INTO purchase_invoices ("id", "job_ref", "company_name", "invoice_number", "invoice_date", "invoice_amount", "created_at") VALUES (E'a4d68369-98da-435e-899d-8b8722b340c6', 26021, E'Bob Shearing', E'1234', E'2025-10-10', 200, E'2025-10-07T09:05:32.797Z');
INSERT INTO purchase_invoices ("id", "job_ref", "company_name", "invoice_number", "invoice_date", "invoice_amount", "created_at") VALUES (E'598be6e3-7ad2-453b-8fd3-ffe6c8cfba8c', 26022, E'Bob Shearing', E'2123', E'2025-10-10', 200, E'2025-10-07T09:05:32.797Z');
INSERT INTO purchase_invoices ("id", "job_ref", "company_name", "invoice_number", "invoice_date", "invoice_amount", "created_at") VALUES (E'effcc689-0eb0-4a88-971b-4bdcb9d83a75', 26022, E'Reserve MSC', E'0', E'2025-10-05', 200, E'2025-10-07T09:10:09.323Z');

