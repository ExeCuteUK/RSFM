-- Backup for job_file_groups
-- 7 records
-- Generated: 2025-10-10T10:23:26.356Z

INSERT INTO job_file_groups ("id", "job_ref", "documents", "rs_invoices", "created_at", "updated_at") VALUES (E'91957cc6-dfde-4ea7-a6d0-8909af878f87', 26002, ARRAY[], ARRAY[], E'2025-10-07T12:46:00.366Z', E'2025-10-07T16:50:32.930Z');
INSERT INTO job_file_groups ("id", "job_ref", "documents", "rs_invoices", "created_at", "updated_at") VALUES (E'ff388e8a-a1ba-46ff-b48b-71c36849dee3', 26022, ARRAY[], ARRAY[], E'2025-10-05T21:45:39.698Z', E'2025-10-06T20:28:28.868Z');
INSERT INTO job_file_groups ("id", "job_ref", "documents", "rs_invoices", "created_at", "updated_at") VALUES (E'6f1b7461-a914-430b-80d7-fc25c655ef62', 26021, ARRAY[], ARRAY[], E'2025-10-04 17:26:37.176275+00', E'2025-10-07T12:20:12.189Z');
INSERT INTO job_file_groups ("id", "job_ref", "documents", "rs_invoices", "created_at", "updated_at") VALUES (E'5f0ea748-4b74-4e49-8024-7b4866431181', 26001, ARRAY[], ARRAY[], E'2025-10-07T12:32:02.587Z', E'2025-10-07T12:41:33.061Z');
INSERT INTO job_file_groups ("id", "job_ref", "documents", "rs_invoices", "created_at", "updated_at") VALUES (E'805dce29-883e-4ee3-a65c-1e4b03ef33a1', 26004, ARRAY[[object Object]], ARRAY[], E'2025-10-07T17:06:07.601Z', E'2025-10-09T23:00:33.482Z');
INSERT INTO job_file_groups ("id", "job_ref", "documents", "rs_invoices", "created_at", "updated_at") VALUES (E'7a1eaadd-73ee-40a3-800c-ec1ac3d54f63', 26005, ARRAY[], ARRAY[], E'2025-10-09 22:08:25.866484+00', E'2025-10-10T08:18:23.110Z');
INSERT INTO job_file_groups ("id", "job_ref", "documents", "rs_invoices", "created_at", "updated_at") VALUES (E'b74bfc47-4a2a-4ce5-9296-5d01b5b205ea', 26003, ARRAY[], ARRAY[], E'2025-10-07T13:03:02.231Z', E'2025-10-10T08:19:06.979Z');

