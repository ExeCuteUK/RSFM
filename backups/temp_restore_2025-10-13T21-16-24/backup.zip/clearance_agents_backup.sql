-- Backup for clearance_agents
-- 3 records
-- Generated: 2025-10-13T21:06:21.358Z

INSERT INTO clearance_agents ("id", "created_by", "created_at", "agent_name", "agent_telephone", "agent_import_email", "agent_export_email", "agent_accounting_email") VALUES (E'48c8a9b4-8edf-4cd4-bac9-a3864fdb39dd', NULL, E'2025-10-10 11:18:02.544918+00', E'PSG Freight Services', E'01304 240567', ARRAY['imports@psg-freight.com','steve.habbershaw@psg-freight.com'], ARRAY['exports@psg-freight.com'], ARRAY['sue.beeby@freighttransport.co.uk']);
INSERT INTO clearance_agents ("id", "created_by", "created_at", "agent_name", "agent_telephone", "agent_import_email", "agent_export_email", "agent_accounting_email") VALUES (E'4184ad20-1d41-4bd0-9ed4-dc19e41ac557', NULL, E'2025-10-10 11:18:02.544918+00', E'GLB Customs Ltd', E'01304 490100', ARRAY['info@glbcustoms.com'], ARRAY['info@glbcustoms.com'], ARRAY['info@glbcustoms.com']);
INSERT INTO clearance_agents ("id", "created_by", "created_at", "agent_name", "agent_telephone", "agent_import_email", "agent_export_email", "agent_accounting_email") VALUES (E'764de24b-ab93-404a-8676-bfaa6561fe11', NULL, E'2025-10-10 11:18:02.544918+00', E'Atanak Forwarding', E'01304 80772', ARRAY['customs@atanak.com'], ARRAY['customs@atanak.com'], ARRAY['customs@atanak.com']);

