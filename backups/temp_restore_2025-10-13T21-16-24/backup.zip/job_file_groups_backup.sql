-- Backup for job_file_groups
-- 1 records
-- Generated: 2025-10-13T21:06:21.371Z

INSERT INTO job_file_groups ("id", "job_ref", "documents", "rs_invoices", "created_at", "updated_at") VALUES (E'a657f382-8664-4dbb-8187-d39f4b95f35e', 26001, '[]'::jsonb, '[]'::jsonb, E'2025-10-13T19:59:45.876Z', E'2025-10-13T20:01:39.735Z');

