-- Backup for settings
-- 1 records
-- Generated: 2025-10-13T13:17:11.880Z

INSERT INTO settings ("id", "import_clearance_fee", "inventory_linked_fee", "commodity_codes_included_free", "additional_commodity_code_charge", "deferment_charge_minimum", "deferment_charge_percentage", "handover_fee") VALUES (E'a38f38f1-88d5-4c1d-b078-53a0d9c651e8', E'55.00', E'20.00', 1, E'5.00', E'45.00', E'1.25', E'30.00');

