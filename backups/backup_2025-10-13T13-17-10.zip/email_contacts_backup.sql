-- Backup for email_contacts
-- 1 records
-- Generated: 2025-10-13T13:17:11.637Z

INSERT INTO email_contacts ("id", "name", "email", "frequency", "created_at", "updated_at") VALUES (E'c93d3452-f3ae-4b64-8c63-7d57eaeff137', NULL, E'paul@rs-international.com', 2, E'2025-10-12 20:09:21.665476+00', E'2025-10-12T22:15:36.358Z');

