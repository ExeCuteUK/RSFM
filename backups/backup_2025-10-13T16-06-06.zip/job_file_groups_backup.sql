-- Backup for job_file_groups
-- 3 records
-- Generated: 2025-10-13T16:06:08.183Z

INSERT INTO job_file_groups ("id", "job_ref", "documents", "rs_invoices", "created_at", "updated_at") VALUES (E'199e2af4-36e2-4ed7-841c-2458e42ac6de', 26003, '[]'::jsonb, '[]'::jsonb, E'2025-10-10T14:15:41.395Z', E'2025-10-10T19:43:43.759Z');
INSERT INTO job_file_groups ("id", "job_ref", "documents", "rs_invoices", "created_at", "updated_at") VALUES (E'635f5f1b-92ed-4c44-aae2-5a3b1ca21776', 26001, '[]'::jsonb, '[]'::jsonb, E'2025-10-10 12:21:22.657193+00', E'2025-10-10T18:59:46.257Z');
INSERT INTO job_file_groups ("id", "job_ref", "documents", "rs_invoices", "created_at", "updated_at") VALUES (E'69a3ffc1-0eab-4e3b-856b-4680886c8657', 26004, '[]'::jsonb, '[]'::jsonb, E'2025-10-10T14:54:24.526Z', E'2025-10-10T19:28:11.314Z');

