-- Backup for general_references
-- 2 records
-- Generated: 2025-10-13T16:06:08.524Z

INSERT INTO general_references ("id", "job_ref", "job_type", "month", "year", "date", "reference_name", "created_at") VALUES (E'1e0b98ed-7ec9-44df-9073-d78d00ca96a6', 26005, E'', 10, 2025, E'2025-10-01T00:00:00.000Z', E'General Reference', E'2025-10-10 18:39:52.627894+00');
INSERT INTO general_references ("id", "job_ref", "job_type", "month", "year", "date", "reference_name", "created_at") VALUES (E'4287f020-b992-4a5a-979d-77d7c6d872ab', 26006, E'', 11, 2025, E'2025-11-01T00:00:00.000Z', E'General Reference', E'2025-10-10 18:40:04.765748+00');

