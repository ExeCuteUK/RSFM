-- Backup for messages
-- 1 records
-- Generated: 2025-10-13T16:06:08.243Z

INSERT INTO messages ("id", "sender_id", "recipient_id", "subject", "content", "attachments", "is_read", "created_at") VALUES (E'422ec44d-433b-4a81-99e8-33cdeeae770d', E'f6ec8b73-01e0-48d4-ab62-4af13cde75d9', E'd0aba207-0936-423c-8c9b-ccd5854634fb', E'This is a Test', E'you might see this at some point.\n\nhello world', '[]'::jsonb, FALSE, E'2025-10-10 16:37:25.341307+00');

